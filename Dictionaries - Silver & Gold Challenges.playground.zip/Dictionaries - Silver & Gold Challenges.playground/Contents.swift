import Cocoa

let teams = [
    "Austin Eastciders":  ["Stef", "JC", "Hugh", "Jesse B", "Justin"],
    "Austin Southerners": ["Jesse G", "Jordan", "Justin L", "James", "Diana"],
    "Austin Northerners": ["Sabrina", "Rebecca", "Brandon", "Devin", "Kat"]
]
let players = Array(teams.values.joined())
print("In the Austin sports league, it consists of the following players:\(players).")

print()
for (teams, players) in teams {
    print("\(teams) has the following players:")
    for pl in players {
        print("\(pl)")
    }
    print()
}



/*var austinEastciders = ["Stef": 1, "JC": 2, "Hugh": 3, "Jesse B": 4, "Justin": 5]
var austinSoutheners = ["Jesse G": 1, "Jordan": 2, "Justin L": 3, "James": 4, "Diana": 5]
var austinNortherners = ["Sabrina": 1, "Rebecca": 2, "Brandon": 3, "Devin": 4, "Kat": 5]
print("In the Austin sports league, it consists of the following players:\(austinEastciders.keys)\(austinSoutheners.keys) \(austinNortherners.keys).")
*/
