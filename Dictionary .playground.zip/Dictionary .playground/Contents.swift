import Cocoa

//*Objective - 10.1 Creating a dictionary
var movieRatings =
[ "Tron": 4, "WarGames": 5, "Sneakers": 4]

//*Objective - 10.2 Using count
movieRatings.count

//*Objective - 10.3 Reading a value from the dictionary
let tronRating = movieRatings["Tron"]

//*Objective - 10.4 Modifying a value
movieRatings["Sneakers"] = 5
movieRatings

//*Objective - 10.5 Updating a value
let oldRating: Int? =
        movieRatings.updateValue(5, forKey: "Tron")
if let lastRating = oldRating, let currentRating =
        movieRatings["Tron"] {
    print("old rating: \(lastRating)")
    print("current rating: \(currentRating)")
}

//*Objective - 10.6 Adding a value
movieRatings["Hackers"] = 5

//*Objective - 10.7 Removing a value
//movieRatings.removeValue(forKey: "Sneakers")

//*Objective - 10.8 Setting the key's value to nil
movieRatings["Sneakers"] = nil

//*Objective - 10.9 Looping through your dictionary
for (key, value) in movieRatings {
    print("The movie \(key) was rated \(value).")
}

//*Objective - 10.10 Accessing just the keys
for movie in movieRatings.keys {
    print("User has rated \(movie).")
}

//*Objective - 10.11 Making the dictionary immutabe - change the var to LET - error messages will arise
//*Objective - 10.12 Make the dictionary mutable again - change LET to VAR

//*Objective - 10.13 Sending keys to an array
let watchedMovies = Array(movieRatings.keys)




